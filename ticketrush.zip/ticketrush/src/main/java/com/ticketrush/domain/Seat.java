package com.ticketrush.domain;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/** unique(event_id, label) guarantees one row per physical seat; booking_id/hold_expires_at drive the sweeps. */
@Entity
@Table(name = "seats",
       uniqueConstraints = @UniqueConstraint(name = "uk_seat_event_label", columnNames = {"event_id", "label"}),
       indexes = {@Index(name = "ix_seat_booking", columnList = "booking_id"),
                  @Index(name = "ix_seat_status_exp", columnList = "status, hold_expires_at")})
@Getter @Setter @NoArgsConstructor
public class Seat {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "event_id", nullable = false)
    private Long eventId;
    @Column(nullable = false, length = 8)
    private String label;
    @Enumerated(EnumType.STRING) private SeatTier tier;
    @Enumerated(EnumType.STRING) private SeatStatus status = SeatStatus.AVAILABLE;
    private Long bookingId;
    private LocalDateTime holdExpiresAt;
}
