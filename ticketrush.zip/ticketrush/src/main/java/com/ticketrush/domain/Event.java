package com.ticketrush.domain;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity @Table(name = "events")
@Getter @Setter @NoArgsConstructor
public class Event {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String venue;
    private LocalDateTime startsAt;
    @Column(precision = 10, scale = 2)
    private BigDecimal basePrice;
    private int totalSeats;
    private LocalDateTime createdAt = LocalDateTime.now();
}
