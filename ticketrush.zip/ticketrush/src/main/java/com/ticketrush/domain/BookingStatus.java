package com.ticketrush.domain;

public enum BookingStatus { HELD, CONFIRMED, CANCELLED, EXPIRED }
