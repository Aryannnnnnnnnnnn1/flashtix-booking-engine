package com.ticketrush.domain;

public enum SeatStatus { AVAILABLE, HELD, BOOKED }
