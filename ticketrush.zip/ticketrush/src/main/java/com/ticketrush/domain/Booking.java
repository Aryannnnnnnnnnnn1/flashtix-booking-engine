package com.ticketrush.domain;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings",
       indexes = {@Index(name = "ix_booking_event", columnList = "event_id"),
                  @Index(name = "ix_booking_user", columnList = "user_id"),
                  @Index(name = "ix_booking_status_exp", columnList = "status, expires_at")})
@Getter @Setter @NoArgsConstructor
public class Booking {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "event_id", nullable = false)
    private Long eventId;
    @Column(name = "user_id", nullable = false)
    private String userId;
    @Enumerated(EnumType.STRING) private BookingStatus status = BookingStatus.HELD;
    private int seatCount;
    @Column(length = 512) private String seatLabels;
    @Column(precision = 4, scale = 2) private BigDecimal surgeMultiplier;
    @Column(precision = 10, scale = 2) private BigDecimal totalPrice;
    @Column(precision = 10, scale = 2) private BigDecimal refundAmount = BigDecimal.ZERO;
    @Column(length = 64, nullable = false, unique = true) private String idempotencyKey;
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime expiresAt;
    private LocalDateTime confirmedAt;
    private LocalDateTime cancelledAt;
}
