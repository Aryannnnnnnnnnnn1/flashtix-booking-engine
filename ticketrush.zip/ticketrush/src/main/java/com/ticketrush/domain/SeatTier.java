package com.ticketrush.domain;

import java.math.BigDecimal;

public enum SeatTier {
    STANDARD("1.00"), PREMIUM("1.50"), VIP("2.50");

    private final BigDecimal multiplier;
    SeatTier(String m) { this.multiplier = new BigDecimal(m); }
    public BigDecimal multiplier() { return multiplier; }
}
