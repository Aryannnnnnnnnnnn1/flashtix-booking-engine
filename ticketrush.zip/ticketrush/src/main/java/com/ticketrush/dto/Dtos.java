package com.ticketrush.dto;

import com.ticketrush.domain.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public final class Dtos {
    private Dtos() {}

    public record EventRequest(
            @NotBlank @Size(max = 150) String name,
            @NotBlank @Size(max = 150) String venue,
            @NotNull @Future LocalDateTime startsAt,
            @NotNull @DecimalMin("1.00") BigDecimal basePrice,
            @Min(1) @Max(26) int rows,
            @Min(1) @Max(100) int seatsPerRow) {}

    public record EventUpdateRequest(
            @NotBlank @Size(max = 150) String name,
            @NotBlank @Size(max = 150) String venue,
            @NotNull @Future LocalDateTime startsAt,
            @NotNull @DecimalMin("1.00") BigDecimal basePrice) {}

    public record EventResponse(Long id, String name, String venue, LocalDateTime startsAt, BigDecimal basePrice,
                                int totalSeats, long availableSeats, BigDecimal currentSurge) {}

    public record SeatResponse(Long id, String label, SeatTier tier, SeatStatus status) {
        public static SeatResponse from(Seat s) { return new SeatResponse(s.getId(), s.getLabel(), s.getTier(), s.getStatus()); }
    }

    public record HoldRequest(
            @NotBlank @Size(max = 100) String userId,
            @NotEmpty @Size(max = 8) List<@NotBlank String> seatLabels) {}

    public record BookingResponse(Long id, Long eventId, String userId, BookingStatus status, List<String> seatLabels,
                                  int seatCount, BigDecimal surgeMultiplier, BigDecimal totalPrice, BigDecimal refundAmount,
                                  LocalDateTime createdAt, LocalDateTime expiresAt, LocalDateTime confirmedAt,
                                  LocalDateTime cancelledAt) {
        public static BookingResponse from(Booking b) {
            return new BookingResponse(b.getId(), b.getEventId(), b.getUserId(), b.getStatus(),
                    Arrays.asList(b.getSeatLabels().split(",")), b.getSeatCount(), b.getSurgeMultiplier(),
                    b.getTotalPrice(), b.getRefundAmount(), b.getCreatedAt(), b.getExpiresAt(),
                    b.getConfirmedAt(), b.getCancelledAt());
        }
    }

    public record EventStats(Long eventId, String name, int totalSeats, long available, long held, long booked,
                             double occupancyPct, BigDecimal currentSurge, BigDecimal netRevenue) {}

    public record RevenueSummary(Long eventId, long paidBookings, BigDecimal netRevenue) {}
}
