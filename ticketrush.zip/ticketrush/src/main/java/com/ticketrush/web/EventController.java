package com.ticketrush.web;

import com.ticketrush.domain.SeatStatus;
import com.ticketrush.dto.Dtos.*;
import com.ticketrush.service.EventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventController {
    private final EventService service;

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public EventResponse create(@Valid @RequestBody EventRequest r) { return service.create(r); }

    @GetMapping
    public List<EventResponse> list() { return service.list(); }

    @GetMapping("/{id}")
    public EventResponse get(@PathVariable Long id) { return service.get(id); }

    @PutMapping("/{id}")
    public EventResponse update(@PathVariable Long id, @Valid @RequestBody EventUpdateRequest r) { return service.update(id, r); }

    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id); }

    @GetMapping("/{id}/seats")
    public List<SeatResponse> seats(@PathVariable Long id, @RequestParam(required = false) SeatStatus status) {
        return service.seats(id, status);
    }
}
