package com.ticketrush.web;

import com.ticketrush.domain.Event;
import com.ticketrush.domain.SeatStatus;
import com.ticketrush.dto.Dtos.*;
import com.ticketrush.repo.*;
import com.ticketrush.service.PricingService;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
public class AnalyticsController {
    private final EventRepository events;
    private final SeatRepository seats;
    private final BookingRepository bookings;
    private final PricingService pricing;

    @GetMapping("/events/{id}")
    @Transactional(readOnly = true)
    public EventStats stats(@PathVariable Long id) {
        Event e = events.findById(id).orElseThrow(() -> ApiException.notFound("Event not found: " + id));
        long held = seats.countByEventIdAndStatus(id, SeatStatus.HELD);
        long booked = seats.countByEventIdAndStatus(id, SeatStatus.BOOKED);
        long available = e.getTotalSeats() - held - booked;
        double occ = e.getTotalSeats() == 0 ? 0 : Math.round(10000.0 * (held + booked) / e.getTotalSeats()) / 100.0;
        BigDecimal net = bookings.netRevenue(id);
        return new EventStats(id, e.getName(), e.getTotalSeats(), available, held, booked, occ,
                pricing.surge(held + booked, e.getTotalSeats()), net == null ? BigDecimal.ZERO : net);
    }

    @GetMapping("/revenue")
    @Transactional(readOnly = true)
    public List<RevenueSummary> revenue() {
        return bookings.revenueByEvent().stream()
                .map(r -> new RevenueSummary(r.getEventId(), r.getBookings(), r.getNetRevenue())).toList();
    }
}
