package com.ticketrush.web;

import com.ticketrush.domain.BookingStatus;
import com.ticketrush.dto.Dtos.*;
import com.ticketrush.service.BookingFacade;
import com.ticketrush.service.BookingService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Validated
public class BookingController {
    private final BookingFacade facade;
    private final BookingService service;

    @PostMapping("/events/{eventId}/holds") @ResponseStatus(HttpStatus.CREATED)
    public BookingResponse hold(@PathVariable Long eventId,
                                @RequestHeader("Idempotency-Key") @Size(min = 8, max = 64) String key,
                                @Valid @RequestBody HoldRequest req) {
        return facade.hold(eventId, req, key);
    }

    @PostMapping("/bookings/{id}/confirm")
    public BookingResponse confirm(@PathVariable Long id) { return facade.confirm(id); }

    @PostMapping("/bookings/{id}/cancel")
    public BookingResponse cancel(@PathVariable Long id) { return facade.cancel(id); }

    @GetMapping("/bookings/{id}")
    public BookingResponse get(@PathVariable Long id) { return service.get(id); }

    @GetMapping("/bookings")
    public Page<BookingResponse> search(@RequestParam(required = false) BookingStatus status,
                                        @RequestParam(required = false) String userId,
                                        @RequestParam(required = false) Long eventId,
                                        @PageableDefault(size = 20, sort = "id", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.search(status, userId, eventId, pageable);
    }
}
