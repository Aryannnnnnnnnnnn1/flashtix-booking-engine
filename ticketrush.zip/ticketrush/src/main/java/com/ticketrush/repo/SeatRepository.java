package com.ticketrush.repo;

import com.ticketrush.domain.Seat;
import com.ticketrush.domain.SeatStatus;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface SeatRepository extends JpaRepository<Seat, Long> {

    List<Seat> findByEventIdAndLabelIn(Long eventId, Collection<String> labels);
    List<Seat> findByEventIdOrderByIdAsc(Long eventId);
    List<Seat> findByEventIdAndStatusOrderByIdAsc(Long eventId, SeatStatus status);
    long countByEventIdAndStatus(Long eventId, SeatStatus status);
    long countByEventIdAndStatusNot(Long eventId, SeatStatus status);
    void deleteByEventId(Long eventId);

    /** The heart of the system: one atomic compare-and-set. Only rows still AVAILABLE flip to HELD. */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Seat s set s.status = com.ticketrush.domain.SeatStatus.HELD, s.bookingId = :bid, " +
           "s.holdExpiresAt = :exp where s.eventId = :eid and s.id in :ids " +
           "and s.status = com.ticketrush.domain.SeatStatus.AVAILABLE")
    int claim(@Param("eid") Long eventId, @Param("ids") Collection<Long> ids,
              @Param("bid") Long bookingId, @Param("exp") LocalDateTime expiresAt);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Seat s set s.status = com.ticketrush.domain.SeatStatus.BOOKED, s.holdExpiresAt = null " +
           "where s.bookingId = :bid and s.status = com.ticketrush.domain.SeatStatus.HELD")
    int markBooked(@Param("bid") Long bookingId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Seat s set s.status = com.ticketrush.domain.SeatStatus.AVAILABLE, s.bookingId = null, " +
           "s.holdExpiresAt = null where s.bookingId = :bid " +
           "and s.status in (com.ticketrush.domain.SeatStatus.HELD, com.ticketrush.domain.SeatStatus.BOOKED)")
    int release(@Param("bid") Long bookingId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Seat s set s.status = com.ticketrush.domain.SeatStatus.AVAILABLE, s.bookingId = null, " +
           "s.holdExpiresAt = null where s.status = com.ticketrush.domain.SeatStatus.HELD and s.holdExpiresAt < :now")
    int releaseExpired(@Param("now") LocalDateTime now);
}
