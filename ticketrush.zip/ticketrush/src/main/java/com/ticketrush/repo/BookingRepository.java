package com.ticketrush.repo;

import com.ticketrush.domain.Booking;
import com.ticketrush.domain.BookingStatus;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Long>, JpaSpecificationExecutor<Booking> {

    interface RevenueRow {
        Long getEventId();
        Long getBookings();
        BigDecimal getNetRevenue();
    }

    Optional<Booking> findByIdempotencyKey(String key);
    boolean existsByEventId(Long eventId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Booking b set b.status = com.ticketrush.domain.BookingStatus.CONFIRMED, b.confirmedAt = :now " +
           "where b.id = :id and b.status = com.ticketrush.domain.BookingStatus.HELD and b.expiresAt > :now")
    int confirm(@Param("id") Long id, @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Booking b set b.status = com.ticketrush.domain.BookingStatus.CANCELLED, " +
           "b.refundAmount = :refund, b.cancelledAt = :now where b.id = :id and b.status = :from")
    int cancel(@Param("id") Long id, @Param("from") BookingStatus from,
               @Param("refund") BigDecimal refund, @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update Booking b set b.status = com.ticketrush.domain.BookingStatus.EXPIRED " +
           "where b.status = com.ticketrush.domain.BookingStatus.HELD and b.expiresAt < :now")
    int expire(@Param("now") LocalDateTime now);

    /** Net revenue = paid (confirmed at some point) minus refunds. Holds that never paid are excluded. */
    @Query("select sum(b.totalPrice - b.refundAmount) from Booking b where b.eventId = :eid and b.confirmedAt is not null " +
           "and b.status in (com.ticketrush.domain.BookingStatus.CONFIRMED, com.ticketrush.domain.BookingStatus.CANCELLED)")
    BigDecimal netRevenue(@Param("eid") Long eventId);

    @Query("select b.eventId as eventId, count(b) as bookings, sum(b.totalPrice - b.refundAmount) as netRevenue " +
           "from Booking b where b.confirmedAt is not null " +
           "and b.status in (com.ticketrush.domain.BookingStatus.CONFIRMED, com.ticketrush.domain.BookingStatus.CANCELLED) " +
           "group by b.eventId order by sum(b.totalPrice - b.refundAmount) desc")
    List<RevenueRow> revenueByEvent();
}
