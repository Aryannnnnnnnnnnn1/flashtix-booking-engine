package com.ticketrush.service;

import com.ticketrush.dto.Dtos.*;
import com.ticketrush.repo.BookingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.stereotype.Service;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

/**
 * Sits OUTSIDE the transaction so a deadlock victim can retry in a fresh tx.
 * Also resolves idempotency races: if two requests with the same key collide on the unique index,
 * the loser simply returns the winner's booking.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BookingFacade {

    private static final int MAX_ATTEMPTS = 4;

    private final BookingService service;
    private final BookingRepository bookings;

    public BookingResponse hold(Long eventId, HoldRequest req, String key) {
        try {
            return retry(() -> service.hold(eventId, req, key));
        } catch (DataIntegrityViolationException dup) {
            return bookings.findByIdempotencyKey(key).map(BookingResponse::from).orElseThrow(() -> dup);
        }
    }

    public BookingResponse confirm(Long id) { return retry(() -> service.confirm(id)); }

    public BookingResponse cancel(Long id) { return retry(() -> service.cancel(id)); }

    private <T> T retry(Supplier<T> op) {
        int attempt = 0;
        while (true) {
            try {
                return op.get();
            } catch (PessimisticLockingFailureException e) {   // deadlock or lock-wait timeout
                if (++attempt >= MAX_ATTEMPTS) throw e;
                log.debug("Lock contention, retry {}/{}", attempt, MAX_ATTEMPTS);
                try {
                    Thread.sleep(ThreadLocalRandom.current().nextLong(10, 30L * attempt + 10));
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw e;
                }
            }
        }
    }
}
