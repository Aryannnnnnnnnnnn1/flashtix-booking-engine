package com.ticketrush.service;

import com.ticketrush.domain.SeatTier;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Price = base x tier multiplier x occupancy-driven surge. The result is snapshotted on the booking. */
@Component
public class PricingService {

    public BigDecimal surge(long unavailableSeats, int totalSeats) {
        if (totalSeats <= 0) return new BigDecimal("1.00");
        double occupancy = (double) unavailableSeats / totalSeats;
        if (occupancy >= 0.90) return new BigDecimal("1.50");
        if (occupancy >= 0.75) return new BigDecimal("1.30");
        if (occupancy >= 0.50) return new BigDecimal("1.15");
        return new BigDecimal("1.00");
    }

    public BigDecimal seatPrice(BigDecimal base, SeatTier tier, BigDecimal surge) {
        return base.multiply(tier.multiplier()).multiply(surge).setScale(2, RoundingMode.HALF_UP);
    }
}
