package com.ticketrush.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Pure function so the policy is trivially unit-testable: 100% if >=48h out, 50% if >=24h, otherwise nothing. */
public final class RefundPolicy {
    private RefundPolicy() {}

    public static BigDecimal refund(BigDecimal paid, long hoursUntilStart) {
        BigDecimal pct = hoursUntilStart >= 48 ? BigDecimal.ONE
                       : hoursUntilStart >= 24 ? new BigDecimal("0.50")
                       : BigDecimal.ZERO;
        return paid.multiply(pct).setScale(2, RoundingMode.HALF_UP);
    }
}
