package com.ticketrush.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class HoldExpiryJob {
    private final BookingService bookings;

    @Scheduled(fixedDelayString = "${hold.expiry-scan-ms:15000}")
    public void run() {
        try {
            bookings.expireHolds();
        } catch (Exception e) {
            log.warn("Hold expiry sweep failed, will retry next tick: {}", e.getMessage());
        }
    }
}
