package com.ticketrush.service;

import com.ticketrush.domain.*;
import com.ticketrush.dto.Dtos.*;
import com.ticketrush.repo.*;
import com.ticketrush.web.ApiException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Every state change is a conditional UPDATE ("compare-and-set") so database row locks, not Java locks,
 * arbitrate races. Methods are all-or-nothing: any failed step throws and rolls the whole tx back.
 *
 * Lock order is always booking row first, then seat rows (hold, confirm, cancel and the expiry sweep),
 * which keeps deadlocks rare; the facade retries the ones that still happen.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BookingService {

    private final EventRepository events;
    private final SeatRepository seats;
    private final BookingRepository bookings;
    private final PricingService pricing;

    @Value("${hold.minutes:10}")
    private long holdMinutes;

    @Transactional
    public BookingResponse hold(Long eventId, HoldRequest req, String idempotencyKey) {
        var replay = bookings.findByIdempotencyKey(idempotencyKey);
        if (replay.isPresent()) return BookingResponse.from(replay.get());

        Event event = events.findById(eventId).orElseThrow(() -> ApiException.notFound("Event not found: " + eventId));
        if (event.getStartsAt().isBefore(LocalDateTime.now()))
            throw ApiException.badRequest("Event has already started");

        List<String> labels = req.seatLabels().stream().distinct().sorted().toList();
        List<Seat> found = seats.findByEventIdAndLabelIn(eventId, labels);
        if (found.size() != labels.size()) throw ApiException.badRequest("One or more seat labels do not exist");

        // Cheap early exit; the atomic claim below is what actually guarantees correctness.
        List<String> taken = found.stream().filter(s -> s.getStatus() != SeatStatus.AVAILABLE).map(Seat::getLabel).toList();
        if (!taken.isEmpty()) throw ApiException.conflict("Seats unavailable: " + taken);

        long unavailable = seats.countByEventIdAndStatusNot(eventId, SeatStatus.AVAILABLE);
        BigDecimal surge = pricing.surge(unavailable, event.getTotalSeats());
        BigDecimal total = found.stream()
                .map(s -> pricing.seatPrice(event.getBasePrice(), s.getTier(), surge))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        LocalDateTime now = LocalDateTime.now();
        Booking b = new Booking();
        b.setEventId(eventId);
        b.setUserId(req.userId());
        b.setSeatCount(labels.size());
        b.setSeatLabels(String.join(",", labels));
        b.setSurgeMultiplier(surge);
        b.setTotalPrice(total);
        b.setIdempotencyKey(idempotencyKey);
        b.setCreatedAt(now);
        b.setExpiresAt(now.plus(Duration.ofMinutes(holdMinutes)));
        bookings.saveAndFlush(b);   // unique(idempotency_key) catches concurrent duplicate requests

        List<Long> ids = found.stream().map(Seat::getId).sorted().toList();   // stable lock order
        int claimed = seats.claim(eventId, ids, b.getId(), b.getExpiresAt());
        if (claimed != ids.size())
            throw ApiException.conflict("Seats were taken by another request; nothing was held");
        return BookingResponse.from(b);
    }

    @Transactional
    public BookingResponse confirm(Long bookingId) {
        Booking b = load(bookingId);
        if (b.getStatus() == BookingStatus.CONFIRMED) return BookingResponse.from(b);   // idempotent

        if (bookings.confirm(bookingId, LocalDateTime.now()) == 0)
            throw ApiException.conflict("Booking cannot be confirmed (expired, cancelled or already processed)");
        int booked = seats.markBooked(bookingId);
        if (booked != b.getSeatCount())
            throw ApiException.conflict("Seat holds were lost before confirmation");   // rolls back the status flip
        return BookingResponse.from(load(bookingId));
    }

    @Transactional
    public BookingResponse cancel(Long bookingId) {
        Booking b = load(bookingId);
        if (b.getStatus() == BookingStatus.CANCELLED || b.getStatus() == BookingStatus.EXPIRED)
            throw ApiException.conflict("Booking is already " + b.getStatus());

        BigDecimal refund = refundFor(b);
        if (bookings.cancel(bookingId, b.getStatus(), refund, LocalDateTime.now()) == 0)
            throw ApiException.conflict("Booking changed concurrently, please retry");
        seats.release(bookingId);
        return BookingResponse.from(load(bookingId));
    }

    /** HELD: nothing was paid, so nothing is refunded. CONFIRMED: see RefundPolicy. */
    BigDecimal refundFor(Booking b) {
        if (b.getStatus() != BookingStatus.CONFIRMED) return BigDecimal.ZERO;
        Event e = events.findById(b.getEventId()).orElseThrow(() -> ApiException.notFound("Event not found"));
        long hours = Duration.between(LocalDateTime.now(), e.getStartsAt()).toHours();
        return RefundPolicy.refund(b.getTotalPrice(), hours);
    }

    @Transactional(readOnly = true)
    public BookingResponse get(Long id) { return BookingResponse.from(load(id)); }

    @Transactional(readOnly = true)
    public Page<BookingResponse> search(BookingStatus status, String userId, Long eventId, Pageable pageable) {
        Specification<Booking> spec = Specification.where(null);
        if (status != null)  spec = spec.and((r, q, cb) -> cb.equal(r.get("status"), status));
        if (userId != null)  spec = spec.and((r, q, cb) -> cb.equal(r.get("userId"), userId));
        if (eventId != null) spec = spec.and((r, q, cb) -> cb.equal(r.get("eventId"), eventId));
        return bookings.findAll(spec, pageable).map(BookingResponse::from);
    }

    /**
     * Called by the scheduler. Same 'now' for both statements keeps seats and bookings consistent.
     * Bookings first, then seats: same lock order as confirm/cancel. A confirm that lost the race sees
     * EXPIRED and fails cleanly; one that won already flipped its seats to BOOKED, which the sweep ignores.
     */
    @Transactional
    public int expireHolds() {
        LocalDateTime now = LocalDateTime.now();
        int expired = bookings.expire(now);
        int seatsFreed = seats.releaseExpired(now);
        if (expired > 0 || seatsFreed > 0) log.info("Expired {} bookings, freed {} seats", expired, seatsFreed);
        return expired;
    }

    private Booking load(Long id) {
        return bookings.findById(id).orElseThrow(() -> ApiException.notFound("Booking not found: " + id));
    }
}
