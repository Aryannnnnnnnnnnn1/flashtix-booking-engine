package com.ticketrush.service;

import com.ticketrush.domain.*;
import com.ticketrush.dto.Dtos.*;
import com.ticketrush.repo.*;
import com.ticketrush.web.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository events;
    private final SeatRepository seats;
    private final BookingRepository bookings;
    private final PricingService pricing;

    /** Creates the event and generates its seat map: first 2 rows VIP, next 3 PREMIUM, rest STANDARD. */
    @Transactional
    public EventResponse create(EventRequest r) {
        Event e = new Event();
        e.setName(r.name());
        e.setVenue(r.venue());
        e.setStartsAt(r.startsAt());
        e.setBasePrice(r.basePrice());
        e.setTotalSeats(r.rows() * r.seatsPerRow());
        events.save(e);

        List<Seat> map = new ArrayList<>(e.getTotalSeats());
        for (int row = 0; row < r.rows(); row++) {
            SeatTier tier = row < 2 ? SeatTier.VIP : row < 5 ? SeatTier.PREMIUM : SeatTier.STANDARD;
            for (int n = 1; n <= r.seatsPerRow(); n++) {
                Seat s = new Seat();
                s.setEventId(e.getId());
                s.setLabel((char) ('A' + row) + String.valueOf(n));
                s.setTier(tier);
                map.add(s);
            }
        }
        seats.saveAll(map);
        return toResponse(e);
    }

    @Transactional(readOnly = true)
    public List<EventResponse> list() { return events.findAll().stream().map(this::toResponse).toList(); }

    @Transactional(readOnly = true)
    public EventResponse get(Long id) { return toResponse(load(id)); }

    /** Price changes only affect future holds; existing bookings keep their snapshot. */
    @Transactional
    public EventResponse update(Long id, EventUpdateRequest r) {
        Event e = load(id);
        e.setName(r.name());
        e.setVenue(r.venue());
        e.setStartsAt(r.startsAt());
        e.setBasePrice(r.basePrice());
        return toResponse(events.save(e));
    }

    @Transactional
    public void delete(Long id) {
        Event e = load(id);
        if (bookings.existsByEventId(id)) throw ApiException.conflict("Event has bookings and cannot be deleted");
        seats.deleteByEventId(id);
        events.delete(e);
    }

    @Transactional(readOnly = true)
    public List<SeatResponse> seats(Long id, SeatStatus status) {
        load(id);
        List<Seat> list = status == null ? seats.findByEventIdOrderByIdAsc(id)
                                         : seats.findByEventIdAndStatusOrderByIdAsc(id, status);
        return list.stream().map(SeatResponse::from).toList();
    }

    Event load(Long id) { return events.findById(id).orElseThrow(() -> ApiException.notFound("Event not found: " + id)); }

    private EventResponse toResponse(Event e) {
        long unavailable = seats.countByEventIdAndStatusNot(e.getId(), SeatStatus.AVAILABLE);
        return new EventResponse(e.getId(), e.getName(), e.getVenue(), e.getStartsAt(), e.getBasePrice(),
                e.getTotalSeats(), e.getTotalSeats() - unavailable, pricing.surge(unavailable, e.getTotalSeats()));
    }
}
