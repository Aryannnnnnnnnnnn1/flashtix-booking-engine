package com.ticketrush.service;

import com.ticketrush.domain.SeatTier;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.assertEquals;

class PricingServiceTest {
    private final PricingService p = new PricingService();

    @Test void surgeBands() {
        assertEquals(new BigDecimal("1.00"), p.surge(0, 100));
        assertEquals(new BigDecimal("1.00"), p.surge(49, 100));
        assertEquals(new BigDecimal("1.15"), p.surge(50, 100));
        assertEquals(new BigDecimal("1.30"), p.surge(75, 100));
        assertEquals(new BigDecimal("1.50"), p.surge(90, 100));
        assertEquals(new BigDecimal("1.00"), p.surge(5, 0));
    }

    @Test void seatPriceMultipliesAndRounds() {
        assertEquals(new BigDecimal("375.00"),
                p.seatPrice(new BigDecimal("100.00"), SeatTier.VIP, new BigDecimal("1.50")));
        assertEquals(new BigDecimal("34.50"),
                p.seatPrice(new BigDecimal("20.00"), SeatTier.PREMIUM, new BigDecimal("1.15")));
    }
}
