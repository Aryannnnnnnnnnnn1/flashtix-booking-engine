package com.ticketrush.service;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.assertEquals;

class RefundPolicyTest {
    private static final BigDecimal PAID = new BigDecimal("200.00");

    @Test void fullRefundAtLeast48h() { assertEquals(new BigDecimal("200.00"), RefundPolicy.refund(PAID, 48)); }
    @Test void halfRefundBetween24And48h() {
        assertEquals(new BigDecimal("100.00"), RefundPolicy.refund(PAID, 47));
        assertEquals(new BigDecimal("100.00"), RefundPolicy.refund(PAID, 24));
    }
    @Test void noRefundInsideLast24h() {
        assertEquals(new BigDecimal("0.00"), RefundPolicy.refund(PAID, 23));
        assertEquals(new BigDecimal("0.00"), RefundPolicy.refund(PAID, -5));
    }
}
