# TicketRush

A concurrency-safe ticket booking engine (Spring Boot 3, Java 21, JPA, MySQL).
Built around one question: **when 10,000 people click the same seat at the same millisecond, who gets it?**
Answer: exactly one, with no Java locks, no double-booking, and no oversold seats.

## Run it

```bash
# zero setup (in-memory H2)
mvn spring-boot:run -Dspring-boot.run.profiles=h2

# or the real thing (MySQL 8 + app in Docker)
docker compose up --build

# then hammer it
python scripts/simulate.py --users 200
```

Requires JDK 21 and Maven 3.9+. The simulator needs only Python 3.8+ (standard library), so it runs on Windows, macOS and Linux.

## How correctness works

| Concern | Mechanism |
|---|---|
| Two users, one seat | `UPDATE seats SET status='HELD' ... WHERE id IN (...) AND status='AVAILABLE'`; the row count tells you if you won. Wrong count means throw and roll back, so holds are all-or-nothing. |
| Duplicate / retried requests | `Idempotency-Key` header with a unique index. A concurrent duplicate loses the insert and returns the winner's booking. |
| Deadlocks | Seat ids are always claimed in sorted order; all flows lock booking row first, then seats. Remaining deadlock victims are retried (jittered backoff) by `BookingFacade`, which sits outside the transaction. If contention persists the API answers `503` + `Retry-After`. |
| Hold expiry vs confirm | `confirm` is `UPDATE ... WHERE status='HELD' AND expires_at > now`. The sweeper expires bookings first, then frees seats, in the same order as confirm. Whoever commits first wins; the other fails cleanly. |
| Money | `BigDecimal` throughout. Price is snapshotted on the booking (surge included), so later price edits never change an existing booking. |

## Business rules

- **Seat map:** first 2 rows VIP (x2.5), next 3 PREMIUM (x1.5), rest STANDARD (x1.0).
- **Surge by occupancy (held + booked):** under 50% x1.00, 50%+ x1.15, 75%+ x1.30, 90%+ x1.50.
- **Holds** last `HOLD_MINUTES` (default 10), max 8 seats per hold.
- **Refunds on cancel:** held (unpaid) none needed; confirmed: 100% if 48h or more before start, 50% if 24h or more, else 0%.
- **Net revenue** = paid minus refunds; holds that never paid are excluded.

## API

| Method | Path | Notes |
|---|---|---|
| POST | `/api/events` | creates event and generates the seat map (`rows` up to 26, `seatsPerRow` up to 100) |
| GET | `/api/events`, `/api/events/{id}` | includes live `availableSeats` and `currentSurge` |
| PUT / DELETE | `/api/events/{id}` | delete refused with 409 if bookings exist |
| GET | `/api/events/{id}/seats?status=AVAILABLE` | |
| POST | `/api/events/{id}/holds` | header `Idempotency-Key` (8-64 chars); body `{"userId","seatLabels":["A1","A2"]}` |
| POST | `/api/bookings/{id}/confirm` / `cancel` | confirm is idempotent |
| GET | `/api/bookings/{id}` | |
| GET | `/api/bookings?status=&userId=&eventId=&page=&size=` | |
| GET | `/api/analytics/events/{id}`, `/api/analytics/revenue` | occupancy, surge, net revenue |

Quick try:

```bash
curl -X POST localhost:8080/api/events -H 'Content-Type: application/json' \
  -d '{"name":"Rock Night","venue":"Arena","startsAt":"2030-01-01T20:00:00","basePrice":100,"rows":10,"seatsPerRow":20}'
curl -X POST localhost:8080/api/events/1/holds -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: demo-key-0001' -d '{"userId":"alice","seatLabels":["A1","A2"]}'
curl -X POST localhost:8080/api/bookings/1/confirm
```

## What `simulate.py` proves

1. 200 users race for one seat: exactly one 201, everyone else 409/503.
2. Overlapping 3-seat holds: no seat in two bookings; held seats = 3 x successful holds.
3. 100 parallel retries with one key: one booking, one row.
4. Confirm vs cancel racing on one booking: booking status and seat status always agree.
5. Mixed hold/confirm/cancel storm: seat counts, analytics and revenue match the booking ledger.

## Layout

```
domain/   entities + enums        repo/     JPA repos with the compare-and-set updates
service/  Booking, Event, Pricing, RefundPolicy, retry facade, expiry job
web/      controllers, error handling      dto/   request/response records
```
