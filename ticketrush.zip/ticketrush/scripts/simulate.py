#!/usr/bin/env python3
"""
TicketRush concurrency simulation. Cross-platform, standard library only (Python 3.8+).

    python scripts/simulate.py                       # against http://localhost:8080
    python scripts/simulate.py --base http://host:8080 --users 300

Every scenario fires requests from many threads released at the same instant, then checks
invariants against the server's own view of the world. Exit code is 1 if any check fails.
"""
import argparse, json, random, sys, threading, time, uuid
import urllib.request, urllib.error
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

BASE = "http://localhost:8080"
FAILS = []


def call(method, path, body=None, headers=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw)
        except Exception:
            return e.code, {"detail": raw.decode(errors="replace")}
    except (urllib.error.URLError, ConnectionError, TimeoutError) as e:
        return 0, {"detail": f"transport error: {e}"}   # surfaced by the checks, never a crash


def blast(fn, n):
    """Run fn(i) on n threads, released together by a barrier. Returns results in order."""
    barrier = threading.Barrier(n)

    def task(i):
        barrier.wait()
        return fn(i)

    with ThreadPoolExecutor(max_workers=n) as pool:
        return list(pool.map(task, range(n)))


def check(name, ok, detail=""):
    print(f"   [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    if not ok:
        FAILS.append(name)


def new_event(rows=10, per_row=20, price="100.00"):
    start = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")
    st, ev = call("POST", "/api/events", {"name": "Sim " + uuid.uuid4().hex[:6], "venue": "Arena",
                                          "startsAt": start, "basePrice": price,
                                          "rows": rows, "seatsPerRow": per_row})
    assert st == 201, (st, ev)
    return ev


def hold(event_id, user, labels, key=None):
    return call("POST", f"/api/events/{event_id}/holds", {"userId": user, "seatLabels": labels},
                {"Idempotency-Key": key or uuid.uuid4().hex})


def seat_states(event_id):
    st, seats = call("GET", f"/api/events/{event_id}/seats")
    return {s["label"]: s["status"] for s in seats}


def bookings_for(event_id, status):
    st, page = call("GET", f"/api/bookings?eventId={event_id}&status={status}&size=1000")
    return page["content"]


# ---------------------------------------------------------------- scenarios
def thundering_herd(users):
    print(f"\n1) Thundering herd: {users} users race for ONE seat")
    ev = new_event()
    res = blast(lambda i: hold(ev["id"], f"u{i}", ["A1"]), users)
    codes = Counter(st for st, _ in res)
    print("   status codes:", dict(codes))
    check("exactly one request wins the seat", codes[201] == 1, f"winners={codes[201]}")
    check("everybody else is told it's taken (409) or to back off (503)",
          codes[201] + codes[409] + codes[503] == users)
    check("seat is HELD exactly once", seat_states(ev["id"])["A1"] == "HELD")


def overlapping_multi_seat(users):
    print(f"\n2) Overlapping multi-seat holds: {users} users each grab 3 of 30 seats")
    ev = new_event(rows=3, per_row=10)
    pool = [f"{r}{n}" for r in "ABC" for n in range(1, 11)]
    rng = random.Random(7)
    wants = [rng.sample(pool, 3) for _ in range(users)]
    res = blast(lambda i: hold(ev["id"], f"u{i}", wants[i]), users)
    won = [b for st, b in res if st == 201]
    seen, overlap = set(), False
    for b in won:
        for lbl in b["seatLabels"]:
            overlap |= lbl in seen
            seen.add(lbl)
    check("no seat appears in two successful bookings", not overlap)
    states = seat_states(ev["id"])
    held = sum(1 for s in states.values() if s == "HELD")
    check("HELD seat count == 3 x successful holds", held == 3 * len(won), f"held={held}, wins={len(won)}")
    check("all-or-nothing: losers hold nothing",
          all(states[l] == "HELD" for b in won for l in b["seatLabels"]) and held == len(seen))


def idempotency(users):
    print(f"\n3) Idempotency: {users} parallel retries with the SAME key")
    ev = new_event()
    key = uuid.uuid4().hex
    res = blast(lambda i: hold(ev["id"], "retry-user", ["B1", "B2"], key), users)
    ids = {b["id"] for st, b in res if st == 201}
    check("every response is the same booking", len(ids) == 1 and all(st == 201 for st, _ in res),
          f"distinct ids={len(ids)}, codes={dict(Counter(st for st, _ in res))}")
    st, page = call("GET", f"/api/bookings?eventId={ev['id']}&userId=retry-user")
    check("only one booking row exists", page["totalElements"] == 1, f"rows={page['totalElements']}")


def confirm_cancel_race(rounds):
    print(f"\n4) Confirm vs cancel race on the same booking ({rounds} rounds, 2 threads each side)")
    ev = new_event()
    labels = [f"C{n}" for n in range(1, rounds + 1)]
    ok = True
    for lbl in labels:
        st, b = hold(ev["id"], "racer", [lbl])
        assert st == 201, (st, b)
        blast(lambda i: call("POST", f"/api/bookings/{b['id']}/{'confirm' if i % 2 == 0 else 'cancel'}"), 4)
        _, final = call("GET", f"/api/bookings/{b['id']}")
        seat = seat_states(ev["id"])[lbl]
        consistent = (final["status"] == "CONFIRMED" and seat == "BOOKED") or \
                     (final["status"] == "CANCELLED" and seat == "AVAILABLE")
        ok &= consistent
        if not consistent:
            print(f"      inconsistent: booking={final['status']} seat={seat}")
    check("booking status and seat status always agree", ok)




def ledger(users):
    print(f"\n5) Mixed storm: hold -> confirm/cancel, then audit the ledger ({users} users)")
    ev = new_event(rows=6, per_row=10)
    pool = [f"{r}{n}" for r in "ABCDEF" for n in range(1, 11)]
    rng = random.Random(11)

    def user_flow(i):
        labels = rng.sample(pool, rng.randint(1, 3))
        st, b = hold(ev["id"], f"s{i}", labels)
        if st != 201:
            return
        action = i % 3
        if action == 0:
            call("POST", f"/api/bookings/{b['id']}/confirm")
        elif action == 1:
            call("POST", f"/api/bookings/{b['id']}/confirm")
            call("POST", f"/api/bookings/{b['id']}/cancel")
        # action == 2: leave the hold dangling

    blast(user_flow, users)
    states = seat_states(ev["id"])
    held_b, conf_b = bookings_for(ev["id"], "HELD"), bookings_for(ev["id"], "CONFIRMED")
    check("HELD seats == seats in HELD bookings",
          sum(1 for s in states.values() if s == "HELD") == sum(b["seatCount"] for b in held_b))
    check("BOOKED seats == seats in CONFIRMED bookings",
          sum(1 for s in states.values() if s == "BOOKED") == sum(b["seatCount"] for b in conf_b))
    st, stats = call("GET", f"/api/analytics/events/{ev['id']}")
    check("analytics seat counts add up to total",
          stats["available"] + stats["held"] + stats["booked"] == stats["totalSeats"], json.dumps(stats))
    _, cancelled = call("GET", f"/api/bookings?eventId={ev['id']}&status=CANCELLED&size=1000")
    paid = sum(float(b["totalPrice"]) for b in conf_b) + \
           sum(float(b["totalPrice"]) - float(b["refundAmount"]) for b in cancelled["content"] if b["confirmedAt"])
    check("analytics net revenue matches the booking ledger",
          abs(float(stats["netRevenue"]) - paid) < 0.01, f"api={stats['netRevenue']} ledger={paid:.2f}")


def main():
    global BASE
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=BASE)
    ap.add_argument("--users", type=int, default=200)
    a = ap.parse_args()
    BASE = a.base.rstrip("/")
    t0 = time.time()
    try:
        call("GET", "/api/events")
    except Exception as e:
        sys.exit(f"Cannot reach {BASE}: {e}")
    thundering_herd(a.users)
    overlapping_multi_seat(a.users)
    idempotency(min(a.users, 100))
    confirm_cancel_race(8)
    ledger(a.users)
    print(f"\nFinished in {time.time() - t0:.1f}s - " + ("ALL CHECKS PASSED" if not FAILS else f"{len(FAILS)} FAILED: {FAILS}"))
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
